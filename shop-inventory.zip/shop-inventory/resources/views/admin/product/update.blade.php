@extends('layouts.admin')
@section('content')
<div class="pagetitle">
	<h1>Product</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="{{ url('/admin') }}">Home</a></li>
		  <li class="breadcrumb-item">Product</li>
		  <li class="breadcrumb-item active">Edit</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Edit Product</h5>
					<!-- Vertical Form -->
					<form class="row g-3" method="post" action="{{ url('api/products/'.$product->id) }}">
						@method('PUT')
						@csrf
						<div class="col-12">
							<label for="name" class="form-label">Name</label>
							<input type="text" class="form-control" id="name" name="name" value="{{ $product->name }}" required>
						</div>
						<div class="col-12">
							<label for="sku" class="form-label">Sku</label>
							<input type="text" class="form-control" id="sku" name="sku" value="{{ $product->sku }}" required>
						</div>
						<div class="col-12">
							<label for="qty" class="form-label">Quantity</label>
							<input type="text" class="form-control" id="qty" name="qty" value="{{ $product->qty }}" required>
						</div>
						<div class="col-12">
							<label for="price" class="form-label">Price</label>
							<input type="text" class="form-control" id="price" name="price" value="{{ $product->price }}" required>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-primary">Update</button>
							<button type="reset" class="btn btn-secondary">Reset</button>
						</div>
					</form><!-- Vertical Form -->
				</div>
			</div>
		</div>
	</div>
</section>

@endsection