@extends('layouts.admin')
@section('content')
<div class="pagetitle">
	<h1>Products</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="{{ url('/admin') }}">Home</a></li>
		  <li class="breadcrumb-item">Products</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Products List</h5>
					@if (session()->has('message'))
						<div class="col-lg-12 col-md-12 alert alert-info">
							{!! session('message') !!}
						</div>
					@endif
					<!-- Primary Color Bordered Table -->
					<div class="table-responsive">
						<table class="table table-bordered border-primary">
							<thead>
								<tr>
									<th scope="col">Sr #</th>
									<th scope="col">Name</th>
									<th scope="col">Sku</th>
									<th scope="col">Quantity</th>
									<th scope="col">Price</th>
									<th scope="col">Action</th>
								</tr>
							</thead>
							<tbody>
								@foreach($products as $key=>$product)
									<tr>
										<th scope="row">{{ $key+1 }}</th>
										<td>{{ $product->name }}</td>
										<td>{{ $product->sku }}</td>
										<td>{{ $product->qty }}</td>
										<td>{{ $product->price }}</td>
										<td>
											@if(Auth::user()->role=="Moderator" || Auth::user()->role=="Administrator")
												<a href="{{ url('admin/product/edit/'.$product->id) }}"><i class="ri-file-edit-fill"></i></a> 
											@endif
											<!-- <a href="{{ url('api/products/'.$product->id) }}" onclick="return confirm('Are you sure you want to delete this product?');"><i class="ri-delete-bin-2-fill"></i></a> -->
											@if(Auth::user()->role=="Administrator")
												<form action="{{ url('api/products/'.$product->id) }}" method="POST">
												 @method('DELETE')
												 @csrf
												 <button type="submit"><i class="ri-delete-bin-2-fill"></i></button>               
												</form>
											@endif
										</td>
									</tr>
								@endforeach
							</tbody>
						</table>
					</div>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>


@endsection