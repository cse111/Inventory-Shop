@extends('layouts.admin')
@section('content')
<div class="pagetitle">
	<h1>Products</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="{{ url('/admin') }}">Home</a></li>
		  <li class="breadcrumb-item">Products</li>
		  <li class="breadcrumb-item active">Add</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Add Product</h5>
					<!-- Vertical Form -->
					<form class="row g-3" method="post" action="{{ url('api/products') }}">
						@csrf
						<div class="col-12">
							<label for="name" class="form-label">Name</label>
							<input type="text" class="form-control" id="name" name="name" value="" required>
						</div>
						<div class="col-12">
							<label for="sku" class="form-label">Sku</label>
							<input type="text" class="form-control" id="sku" name="sku" value="" required>
						</div>
						<div class="col-12">
							<label for="qty" class="form-label">Quantity</label>
							<input type="text" class="form-control" id="qty" name="qty" value="" required>
						</div>
						<div class="col-12">
							<label for="price" class="form-label">Price</label>
							<input type="text" class="form-control" id="price" name="price" value="" required>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-primary">Submit</button>
							<button type="reset" class="btn btn-secondary">Reset</button>
						</div>
					</form><!-- Vertical Form -->
				</div>
			</div>
		</div>
	</div>
</section>

@endsection