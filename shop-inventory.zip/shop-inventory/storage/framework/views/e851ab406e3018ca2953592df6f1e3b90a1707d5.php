
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Users</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Users</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Users</h5>
					<!-- Primary Color Bordered Table -->
					<div class="table-responsive">
						<table class="table table-bordered border-primary">
							<thead>
								<tr>
									<th scope="col">Sr #</th>
									<th scope="col">Name</th>
									<th scope="col">Email</th>
									<th scope="col">Role</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<th scope="row"><?php echo e($key+1); ?></th>
										<td><?php echo e($user->name); ?></td>
										<td><?php echo e($user->email); ?></td>
										<td><?php echo e($user->role); ?></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ovpms\resources\views/admin/user/index.blade.php ENDPATH**/ ?>