
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Parking Area</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Reserved Parking Area Slots</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Reserved Parking Area Slot List</h5>
					<?php if(session()->has('message')): ?>
						<div class="col-lg-12 col-md-12 alert alert-info">
							<?php echo session('message'); ?>

						</div>
					<?php endif; ?>
					
					<!-- Primary Color Bordered Table -->
					<table class="table table-bordered border-primary">
						<thead>
							<tr>
								<th scope="col">Sr #</th>
								<th scope="col">Parking Area Name</th>
								<th scope="col">Slot #</th>
								<th scope="col">Status</th>
								<th scope="col">Check In</th>
								<th scope="col">Check Out</th>
								<th scope="col">Amount</th>
								<th scope="col">Reserved By</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $reserved_parking_area_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$reserved_parking_area_slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th scope="row"><?php echo e($key+1); ?></th>
									<td><?php echo e($reserved_parking_area_slot->getParkingAreaDetail->name); ?></td>
									<td><?php echo e($reserved_parking_area_slot->slot_no); ?></td>
									<td><span class="text-success"><strong>Reserved</strong></span></td>
									<td><?php echo e($reserved_parking_area_slot->check_in); ?></td>
									<td><?php echo e($reserved_parking_area_slot->check_out); ?></td>
									<td><?php echo e($reserved_parking_area_slot->amount); ?></td>
									<td>
										<?php if(@$reserved_parking_area_slot->getUserVehicleDetail->name): ?>
											<?php echo e(@$reserved_parking_area_slot->getUserVehicleDetail->name. ' ('.@$reserved_parking_area_slot->getUserVehicleDetail->model.')'); ?><br>
											Number Plate No.: <?php echo e(@$reserved_parking_area_slot->getUserVehicleDetail->number_plate_no); ?>

										<?php endif; ?>
									</td>
									<td>
										<a href="<?php echo e(url('admin/reserved-slots/check-in-out/'.$reserved_parking_area_slot->id)); ?>">Check In / Check Out</a> 
										<?php if($reserved_parking_area_slot->check_out): ?>
											|
											<a class="print" href="<?php echo e(url('admin/reserved-slots/print/'.$reserved_parking_area_slot->id)); ?>" data-id="<?php echo e($reserved_parking_area_slot->id); ?>">Print</a>
											<div class="d-none" id='DivIdToPrint_<?php echo e($reserved_parking_area_slot->id); ?>'>
												<div class="container">
													<div class="text-center">
														<h5>Online Vehicle Parking Management System</h5>
														<p>
														Parking Area: <?php echo e($reserved_parking_area_slot->getParkingAreaDetail->name); ?><br>
														Slot: <?php echo e($reserved_parking_area_slot->slot_no); ?><br>
														</p>
														
														Check In: <?php echo e($reserved_parking_area_slot->check_in); ?><br>
														Check Out: <?php echo e($reserved_parking_area_slot->check_out); ?> <br>
														Charges: <?php echo e($reserved_parking_area_slot->amount); ?> <br>
														
														<p> Thanks for visiting us.</p>
													</div>
												</div>
											</div>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ovpms\resources\views/admin/reserved-parking-area-slot/index.blade.php ENDPATH**/ ?>