
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Check In /Check Out</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Reserved Parking Area Slot</li>
		  <li class="breadcrumb-item active">Check In /Check Out</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-8">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Check In /Check Out</h5>
					<!-- Vertical Form -->
					<form class="row g-3" method="post" action="<?php echo e(url('admin/reserved-slots/check-in-out')); ?>">
						<?php echo csrf_field(); ?>
						<div class="col-12">
							<label for="parking_area_id" class="form-label">Parking Area</label>
							<input type="text" class="form-control" id="" name="" value="<?php echo e($parking_area_slot->getParkingAreaDetail->name); ?>" readonly required>
							<input type="hidden" class="form-control" id="parking_area_id" name="parking_area_id" value="<?php echo e($parking_area_slot->parking_area_id); ?>" readonly>
						</div>
						<div class="col-12">
							<label for="name" class="form-label">Slot No.</label>
							<input type="text" class="form-control" id="" name="" value="<?php echo e($parking_area_slot->slot_no); ?>" readonly required>
							<input type="hidden" class="form-control" id="slot_id" name="slot_id" value="<?php echo e($parking_area_slot->id); ?>" readonly required>
						</div>
						
						<div class="col-12">
							<label for="name" class="form-label">Reserved By</label>
							<input type="text" class="form-control" id="" name="" value="<?php echo e($parking_area_slot->getUserVehicleDetail-> getUserDetail->name.' (Vehicle: '.$parking_area_slot->getUserVehicleDetail->name.', Model: '.$parking_area_slot->getUserVehicleDetail->model.', Number Plate:  '.$parking_area_slot->getUserVehicleDetail->number_plate_no.')'); ?>" readonly required>
						</div>
						<div class="col-12">
							<label for="name" class="form-label">Amount</label>
							<input type="text" class="form-control" id="amount" name="amount" value="50" readonly>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
					</form><!-- Vertical Form -->
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ovpms\resources\views/admin/reserved-parking-area-slot/check-in-out.blade.php ENDPATH**/ ?>