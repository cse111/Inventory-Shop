<?php $__env->startSection('content'); ?>
<!-- breadcrumbs -->
<section class="bg-cherry pt-s3 pb-s3 text-white">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="d-lg-flex text-center">
					<div class="align-self-center mb-0--lg mb-s1--md mb-s1--sm mb-s1--xs">
						<h3 class="text-bold-400 text-size-s2 m-0 text-white">Vehicle Registration</h3>
					</div>
					<div class="ml-auto align-self-center">
						<ol class="breadcrumb d-flex justify-content-center m-0 bg-none text-size-s1 p-0">
							<li class="breadcrumb-item"><a class="text-white" href="<?php echo e(url('/')); ?>">Home</a></li>
							<li class="breadcrumb-item" aria-current="page">Vehicle Registration</li>
						</ol>
					</div>
				</div>
			</div>
		</div> <!-- ROW -->
	</div> <!-- /CONTAINER -->
</section>
<!-- /breadcrumbs -->

<section class="bg-white pt-s5 pb-s5">
	<div class="container">
		<div>
			<div class="row">
				<div class="col-md-12">
					<div>
						<?php if(session()->has('message')): ?>
							<div class="col-lg-12 col-md-12 alert alert-success">
								<?php echo session('message'); ?>

							</div>
						<?php endif; ?>
						<div class="mb-30">
							<h3 class="text-bold-700 text-dark">Register Your Vehicle</h3> 
							<div class="mb-s3">
								<hr class="mb-0 bc-v1-dark">
								<hr class="w--60 bs-solid bc-cherry bw-s5 bt-0 bl-0 br-0 mt-0 ml-0">
							</div>
						</div>
						<form method="POST" action="<?php echo e(url('/register-vehicle')); ?>">
							<?php echo csrf_field(); ?>
							<input type="hidden" name="role" value="User" >
							<div class="row">
								<div class="form-group col-md-6">
									<label class="text-size-12 text-bold-500">Vehicle Name<span class="text-danger">*</span></label>
									<input type="text" name="name" value="<?php echo e(@Auth::user()->getVehicleDetail->name); ?>" class="form-control bg-light text-size-12 pt-8 pb-8 pl-20 pr-20 text-bold-600 rounded-0 bc-v1-dark" required>
								</div>
								<div class="form-group col-md-6">
									<label class="text-size-12 text-bold-500">Vehicle Model<span class="text-danger">*</span></label>
									<input type="text" name="model" value="<?php echo e(@Auth::user()->getVehicleDetail->model); ?>" class="form-control bg-light text-size-12 pt-8 pb-8 pl-20 pr-20 text-bold-600 rounded-0 bc-v1-dark" required>
								</div>
							</div>
							
							<div class="row">
								<div class="form-group col-md-6">
									<label class="text-size-12 text-bold-500">Vehicle Number Plate No.<span class="text-danger">*</span></label>
									<input type="text" name="number_plate_no" value="<?php echo e(@Auth::user()->getVehicleDetail->number_plate_no); ?>" class="form-control bg-light text-size-12 pt-8 pb-8 pl-20 pr-20 text-bold-600 rounded-0 bc-v1-dark" required>
								</div>
							</div>

							<button type="submit" class="btn bg-cherry text-white text-shadow-s1 text-uppercase text-bold-600 text-size-s1 rounded-0 pt-8 pb-8 pl-20 pr-20 box-shadow-v1-s3--hover mt-10">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div> <!-- /CONTAINER -->
</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\ovpms\resources\views/front/vehicle/create.blade.php ENDPATH**/ ?>