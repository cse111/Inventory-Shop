
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Products</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Products</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Products List</h5>
					<?php if(session()->has('message')): ?>
						<div class="col-lg-12 col-md-12 alert alert-info">
							<?php echo session('message'); ?>

						</div>
					<?php endif; ?>
					<!-- Primary Color Bordered Table -->
					<div class="table-responsive">
						<table class="table table-bordered border-primary">
							<thead>
								<tr>
									<th scope="col">Sr #</th>
									<th scope="col">Name</th>
									<th scope="col">Sku</th>
									<th scope="col">Quantity</th>
									<th scope="col">Price</th>
									<th scope="col">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<th scope="row"><?php echo e($key+1); ?></th>
										<td><?php echo e($product->name); ?></td>
										<td><?php echo e($product->sku); ?></td>
										<td><?php echo e($product->qty); ?></td>
										<td><?php echo e($product->price); ?></td>
										<td>
											<?php if(Auth::user()->role=="Moderator" || Auth::user()->role=="Administrator"): ?>
												<a href="<?php echo e(url('admin/product/edit/'.$product->id)); ?>"><i class="ri-file-edit-fill"></i></a> 
											<?php endif; ?>
											<!-- <a href="<?php echo e(url('api/products/'.$product->id)); ?>" onclick="return confirm('Are you sure you want to delete this product?');"><i class="ri-delete-bin-2-fill"></i></a> -->
											<?php if(Auth::user()->role=="Administrator"): ?>
												<form action="<?php echo e(url('api/products/'.$product->id)); ?>" method="POST">
												 <?php echo method_field('DELETE'); ?>
												 <?php echo csrf_field(); ?>
												 <button type="submit"><i class="ri-delete-bin-2-fill"></i></button>               
												</form>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-inventory\resources\views/admin/product/index.blade.php ENDPATH**/ ?>