
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Parking Area</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Parking Area</li>
		  <li class="breadcrumb-item active">Edit</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Update Your Parking Area</h5>
					<!-- Vertical Form -->
					<form class="row g-3" method="post" action="<?php echo e(url('admin/parking-area/update/'.$parking_area->id)); ?>">
						<?php echo csrf_field(); ?>
						<div class="col-12">
							<label for="name" class="form-label">Parking Area Name</label>
							<input type="text" class="form-control" id="name" name="name" value="<?php echo e($parking_area->name); ?>" required>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-primary">Submit</button>
							<button type="reset" class="btn btn-secondary">Reset</button>
						</div>
					</form><!-- Vertical Form -->
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/admin/parking-area/update.blade.php ENDPATH**/ ?>