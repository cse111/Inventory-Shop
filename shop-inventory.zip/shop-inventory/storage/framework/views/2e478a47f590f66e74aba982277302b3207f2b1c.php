
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Dashboard</h1>
	<nav>
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="index.html">Home</a></li>
			<li class="breadcrumb-item active">Dashboard</li>
		</ol>
	</nav>
</div>
<!-- End Page Title -->
<section class="section dashboard">
	<div class="row">
		<!-- Left side columns -->
		<div class="col-lg-12">
			<div class="row">
				<!-- Total Accounts Card -->
				<div class="col-xxl-4 col-md-6">
					<div class="card info-card revenue-card">
						<div class="card-body">
							<h5 class="card-title">Total Accounts</h5>
							<div class="d-flex align-items-center">
								<div class="card-icon rounded-circle d-flex align-items-center justify-content-center"> <i class="bi bi-people"></i> </div>
								<div class="ps-3">
									<h6></h6>  </div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Total Accounts Card -->
				<!-- Total Products Card -->
				<div class="col-xxl-4 col-md-6">
					<div class="card info-card revenue-card">
						<div class="card-body">
							<h5 class="card-title">Total Products</h5>
							<div class="d-flex align-items-center">
								<div class="card-icon rounded-circle d-flex align-items-center justify-content-center"> <i class="bi bi-card-list"></i> </div>
								<div class="ps-3">
									<h6></h6>  </div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Total Products Card -->
			</div>
		</div>
		<!-- End Left side columns -->
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
i {
  font-size: 2.2rem;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-inventory\resources\views/admin/index.blade.php ENDPATH**/ ?>