<ul class="sidebar-nav" id="sidebar-nav">
	<li class="nav-item">
		<a class="nav-link " href="<?php echo e(url('/admin')); ?>">
		  <i class="bi bi-grid"></i>
		  <span>Dashboard</span>
		</a>
	</li><!-- End Dashboard Nav -->

	<li class="nav-item">
		<a class="nav-link collapsed" data-bs-target="#parking-area-nav" data-bs-toggle="collapse" href="#">
		  <i class="bi bi-menu-button-wide"></i><span>Parking Area</span><i class="bi bi-chevron-down ms-auto"></i>
		</a>
		<ul id="parking-area-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
			<li>
				<a href="<?php echo e(url('/admin/parking-area/create')); ?>">
				  <i class="bi bi-circle"></i><span>Add</span>
				</a>
		    </li>
		    <li>
				<a href="<?php echo e(url('/admin/parking-area')); ?>">
				  <i class="bi bi-circle"></i><span>List</span>
				</a>
		    </li>
		</ul>
    </li><!-- End Parking Area Nav -->
	
	<li class="nav-item">
		<a class="nav-link collapsed" data-bs-target="#parking-area-slot-nav" data-bs-toggle="collapse" href="#">
		  <i class="bi bi-menu-button-wide"></i><span>Parking Area Slot</span><i class="bi bi-chevron-down ms-auto"></i>
		</a>
		<ul id="parking-area-slot-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
			<li>
				<a href="<?php echo e(url('/admin/parking-area-slot/create')); ?>">
				  <i class="bi bi-circle"></i><span>Add</span>
				</a>
		    </li>
		    <li>
				<a href="<?php echo e(url('/admin/parking-area-slot')); ?>">
				  <i class="bi bi-circle"></i><span>List</span>
				</a>
		    </li>
		</ul>
    </li><!-- End Parking Area Slot Nav -->
	
	<li class="nav-item">
		<a class="nav-link collapsed" data-bs-target="#staff-nav" data-bs-toggle="collapse" href="#">
		  <i class="bi bi-person"></i><span>Parking Area Staff</span><i class="bi bi-chevron-down ms-auto"></i>
		</a>
		<ul id="staff-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
			<li>
				<a href="<?php echo e(url('/admin/staff/create')); ?>">
				  <i class="bi bi-circle"></i><span>Add</span>
				</a>
		    </li>
		    <li>
				<a href="<?php echo e(url('/admin/staff')); ?>">
				  <i class="bi bi-circle"></i><span>List</span>
				</a>
		    </li>
		</ul>
    </li><!-- End Parking Area Staff Nav -->
	
	<li class="nav-item">
		<a class="nav-link collapsed" href="<?php echo e(url('/admin/reserved-slots')); ?>">
		  <i class="bi bi-menu-button-wide"></i>
		  <span>Reserved Slots</span>
		</a>
	</li><!-- End Reserved Slots Nav-->
	
	<li class="nav-item">
		<a class="nav-link collapsed" href="<?php echo e(url('/admin/revenue-report')); ?>">
		  <i class="bi bi-journal-text"></i>
		  <span>Revenue Report</span>
		</a>
	</li><!-- End Revenue Report Nav-->
	<?php if(Auth::user()->role=='Administrator'): ?>
		<li class="nav-item">
			<a class="nav-link collapsed" href="<?php echo e(url('/admin/users')); ?>">
			  <i class="bi bi-people"></i>
			  <span>Users</span>
			</a>
		</li><!-- End Users Nav -->
	<?php endif; ?>
</ul><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/_partials/admin-sidebar.blade.php ENDPATH**/ ?>