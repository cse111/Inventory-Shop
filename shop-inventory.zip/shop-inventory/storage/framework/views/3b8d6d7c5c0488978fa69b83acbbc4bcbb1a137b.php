<nav class="main-menu menu-caret menu-hover-2 submenu-top-border submenu-scale">
	<ul>
		<li class="<?php if(Request::segment(1)==''): ?> current-menu <?php endif; ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
		<li class="<?php if(Request::segment(1)=='parking-area'): ?> current-menu <?php endif; ?>"><a href="<?php echo e(url('/parking-area')); ?>">Parkings</a></li>
		<li><a href="#">Contact Us</a></li>
	</ul>
</nav> <!-- NAVIGATION MENU --><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/_partials/front-nav.blade.php ENDPATH**/ ?>