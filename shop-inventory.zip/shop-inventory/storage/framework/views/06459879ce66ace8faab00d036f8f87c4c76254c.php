
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Revenue Report</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Report</li>
		  <li class="breadcrumb-item active">Revenue Report</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">

		  <div class="card">
			<div class="card-body">
			  <h5 class="card-title">Filters</h5>
			  <form class="row g-3" method="post">
				<?php echo csrf_field(); ?>
                <div class="col-md-4">
                  <label for="parking_area_id" class="form-label">Parking Area</label>
				  <select id="parking_area_id" name="parking_area_id" class="form-select">
                    <option value="">-- Select Parking Area --</option>
					<?php $__currentLoopData = $parking_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option <?php if($request->parking_area_id==$parking_area->id): ?> selected <?php endif; ?> value="<?php echo e($parking_area->id); ?>"><?php echo e($parking_area->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
				<div class="col-md-3">
                  <label for="parking_area_id" class="form-label">From</label>
				  <input type="date" class="form-control" id="" name="from" value="<?php echo e(@$request->from); ?>">
                </div>
                <div class="col-md-3">
                  <label for="parking_area_id" class="form-label">To</label>
				  <input type="date" class="form-control" id="" name="to" value="<?php echo e(@$request->to); ?>">
                </div>
				<div class="col-md-2">
				
                  <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                </div>
              </form>
			</div>
		  </div>

		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title"></h5>
					<!-- Primary Color Bordered Table -->
					<table class="table table-bordered border-primary">
						<thead>
							<tr>
								<th scope="col">Parking Area Name</th>
								<th scope="col">Slot #</th>
								<th scope="col">date</th>
								<th scope="col">Revenue Earned</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$total_revenue = 0;
							?>
							<?php $__currentLoopData = $revenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($data->getParkingAreaDetail->name); ?></td>
									<td><?php echo e($data->getParkingAreaSlotDetail->slot_no); ?></td>
									<td><?php echo e(date('d-M-Y',strtotime($data->date))); ?></td>
									<td>
									<?php echo e($data->amount); ?>

									 <?php 
										$total_revenue+=@$data->amount;
									 ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><strong>Total</strong></td>
									<td></td>
									<td></td>
									<td><strong><?php echo e(@$data->amount); ?></strong></td>
								</tr>
						</tbody>
					</table>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	<style>
		.submit-btn {
			margin-top: 16%;
		}
	</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/admin/report/revenue-report.blade.php ENDPATH**/ ?>