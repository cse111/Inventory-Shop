
<?php $__env->startSection('content'); ?>
<section class="pt-s5 pb-s5 overlay-wrap" data-plugin-parallax data-plugin-options="{'speed': 1.5}" data-image-src="assets/images/bg/bg-1.jpg">
	<div class="container overlay-container pt-s2 pb-s5">
		<div class="pb-s5">
			<div class="hero-section-container-tl w-100 h-100 d-flex justify-content-center align-items-center">
				<div class="text-center mb-s2">
					<div class="mt-s3 text-white">
						<h6>Find Parking Area at Your Convenience</h6>
					</div>
					<div class="mt-s1 mb-s5 text-white">
						<h1 class="animated-headline letters type mb-s2 text-white text-size-20--xs text-size-30--sm">
							<span class="headline-wrapper text-cherry text-capitalize">
								<b class="is-visible">Reserve your parking slot</b>
							</span>
						</h1>
					</div>
				</div>
			</div>
		</div>
	</div> <!-- /CONTAINER -->
	<div class="overlay bg-v9-dark"></div>
</section> <!-- /SECTION -->
<section class="bg-v5-light pt-s3 pb-s3">
		<div class="quote-setting container">
			<div class="bg-white p-s3 bs-solid bc-light bw-s1 rounded-s2 box-shadow-v1-s5">
				<form class="quote-hr" action="<?php echo e(url('/parking-area')); ?>" method="post">
					<?php echo csrf_field(); ?>
					<div class="row">
						<div class="col-lg-10">
							<label>Search parking area and reserve your parking slot according to your choice.</label>
							<div class="form-row">
								<div class="form-group col-md-12">
									<input type="text" class="form-control text-size-12 rounded-s5 bc-v1-dark" name="parking_area">
								</div>
								
							</div>
						</div>
						<div class="col-lg-2">
							<div class="form-row">
								<div class="form-group col-md-12">
									<button type="submit" class="btn bg-cherry text-white text-shadow-s1 text-uppercase text-bold-600 text-size-s1 mt-30 rounded-s5 mb-s1 btn-block">Search</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div> <!-- /CONTAINER --> 
		<div class="container pt-s4">
			<div class="row pl-16">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="row">
						<div class="col-lg-12 col-md-6 position-relative">
							<div class="mb-s2 position-relative">
								<h3 class="text-center">Parking Area</h3>
								<div class="row">
									<div class="col-lg-12 col-md-12 p-0">
										<div class="bg-white pt-s3 pl-s3 pr-s3 pb-s3 match-height">
											<div class="row">
												<?php $__currentLoopData = $parking_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="col-lg-4 col-md-12">
														<h2 class="text-size-20 text-bold-600 text-capitalize mb-20 mt-20"><?php echo e($parking_area->name); ?></h2>
														<div class="mt-20 mb-20">
															<a href="<?php echo e(url('parking-area-slot/'.$parking_area->id)); ?>" class="btn bg-cherry text-white text-shadow-s1 text-uppercase text-bold-600 text-size-s1 rounded-0 pt-8 pb-8 pl-20 pr-20 box-shadow-v1-s3--hover">Reserve Now</a>
														</div>
													</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
									</div>
								</div> <!-- /ROW -->
							</div>
						</div>
					</div> <!-- /ROW -->
				</div>
				
			</div> <!-- /ROW -->

			<!-- <div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="d-flex justify-content-between align-items-center mt-s4">
						<div>
							<nav>
								<ul class="list-inline">
									<li class="list-inline-item m-0 float-left"><a class="page-link text-size-s1 rounded-0 p-s2 text-dark bg-cherry--active text-white--active bc-cherry--active" href="#">Previous</a></li>
									<li class="list-inline-item m-0 float-left"><a class="page-link text-size-s1 rounded-0 p-s2 text-dark bg-cherry--active text-white--active bc-cherry--active active" href="#">1</a></li>
									<li class="list-inline-item m-0 float-left"><a class="page-link text-size-s1 rounded-0 p-s2 text-dark bg-cherry--active text-white--active bc-cherry--active" href="#">2</a></li>
									<li class="list-inline-item m-0 float-left"><a class="page-link text-size-s1 rounded-0 p-s2 text-dark bg-cherry--active text-white--active bc-cherry--active" href="#">3</a></li>
									<li class="list-inline-item m-0 float-left"><a class="page-link text-size-s1 rounded-0 p-s2 text-dark bg-cherry--active text-white--active bc-cherry--active" href="#">Next</a></li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</div> -->  <!-- /ROW -->

		</div> <!-- /CONTAINER -->
	</section> <!-- /SECTION -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/front/parking-area.blade.php ENDPATH**/ ?>