
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>My Profile</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item active">My Profile</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">My Profile</h5>
					<?php if(session()->has('message')): ?>
						<div class="col-lg-12 col-md-12 alert alert-info">
							<?php echo session('message'); ?>

						</div>
					<?php endif; ?>
					<!-- Vertical Form -->
					<form class="row g-3" method="post" action="<?php echo e(url('admin/profile')); ?>">
						<?php echo csrf_field(); ?>
						<div class="col-12">
							<label for="name" class="form-label">Name</label>
							<input type="text" class="form-control" id="name" name="name" value="<?php echo e(Auth::user()->name); ?>" required>
						</div>
						<div class="col-12">
							<label for="email" class="form-label">Email</label>
							<input type="email" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
						</div>
						<div class="col-12">
							<label for="password" class="form-label">Password</label>
							<input type="text" class="form-control" id="password" name="password" value="">
						</div>
						
						<div class="text-center">
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
					</form><!-- Vertical Form -->
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ovpms\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>