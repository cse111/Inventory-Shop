
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Parking Area</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Parking Area</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Parking Area List</h5>
					<?php if(session()->has('message')): ?>
						<div class="col-lg-12 col-md-12 alert alert-info">
							<?php echo session('message'); ?>

						</div>
					<?php endif; ?>
					<!-- Primary Color Bordered Table -->
					<table class="table table-bordered border-primary">
						<thead>
							<tr>
								<th scope="col">Sr #</th>
								<th scope="col">Role</th>
								<th scope="col">Owner Name</th>
								<th scope="col">Parking Area Name</th>
								<th scope="col">status</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $parking_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$parking_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th scope="row"><?php echo e($key+1); ?></th>
									<td><?php echo e(@$parking_area->getRole->role); ?></td>
									<td><?php echo e(@$parking_area->getRole->name); ?></td>
									<td><?php echo e($parking_area->name); ?></td>
									<td>
										<?php if($parking_area->status==0): ?>
											<span class="text-danger"><strong>Pending</strong></span>
										<?php else: ?>
											<span class="text-success"><strong>Approved</strong></span>
										<?php endif; ?>	
									</td>
									<td>
										<a href="<?php echo e(url('admin/parking-area/edit/'.$parking_area->id)); ?>"><i class="ri-file-edit-fill"></i></a>
										<a href="<?php echo e(url('admin/parking-area/delete/'.$parking_area->id)); ?>" onclick="return confirm('Are you sure you want to delete this parking area?');"><i class="ri-delete-bin-2-fill"></i></a>
										<a target="_blank" href="<?php echo e(url('admin/staff/'.$parking_area->id)); ?>"><i class="ri-file-user-fill"></i></a>
										<?php if(Auth::user()->role=="Administrator"): ?>
											<a class="ml-5" href="<?php echo e(url('admin/parking-area/status/'.$parking_area->id.'/1')); ?>" onClick="return confirm('Are you sure you want to approve this parking area?')">Approved</a> |
											<a href="<?php echo e(url('admin/parking-area/status/'.$parking_area->id.'/0')); ?>" onClick="return confirm('Are you sure you want to disapprove this parking area?')">Disapproved</a>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
	.ml-5 {
		margin-left: 5%;
	}	
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ovpms\resources\views/admin/parking-area/index.blade.php ENDPATH**/ ?>