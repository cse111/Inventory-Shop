<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Vehicle Parking Management System</title>

	<!-- <link rel="shortcut icon" href="<?php echo e(asset('public/assets/front/images/logo/favicon.png')); ?>">
	<link rel="apple-touch-icon" href="<?php echo e(asset('public/assets/front/images/logo/apple-touch-icon.png')); ?>"> -->

	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/bootstrap.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('public/assets/front/vendors/menu/src/main.menu.css')); ?>">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/utilities.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/colors.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/colors-gh.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/css/colors-g.css')); ?>">

	<!-- CAROUSEL -->
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/front/vendors/owl.carousel/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/front/vendors/owl.carousel/owl.theme.default.min.css')); ?>">

	<!-- ANIMATE -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/vendors/animate/animate.css')); ?>">

	<!-- ANIMATED HEADLINES -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/vendors/animated-headline/css/style.css')); ?>">

	<!-- FANCY BOX -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/front/vendors/fancybox/jquery.fancybox.min.css')); ?>">

</head>
<body>

	<div class="main-header header-shadow cherry-header">
	    <div class="bg-cherry">
	        <div class="container">
	            <div class="row">
	                <div class="col-lg-6 col-md-12">
	                    <div class="text-white mt-10 text-center--md text-center--sm text-center--xs">
	                        Helpline 0123456789
	                    </div>
	                </div>
	                <div class="col-lg-6 col-md-12">
	                    <div class="text-right text-center--md text-center--sm text-center--xs">
	                        <span class="text-white mt-8 pl-20 pr-20 d-inline-block">
	                            Welcome  <span class="text-bold-600"><?php echo e(@Auth::user()->name); ?></span> 
	                        </span>
	                        <!-- <a class="btn btn-white text-cherry text-size-11 text-bold-600 mt-5 mb-5 mt-10--md mb-10--md mt-10--sm mb-10--sm mt-10--xs mb-10--xs text-uppercase" href="my-bookings.html"><i class="zmdi zmdi-account-o text-size-15 mr-6 float-left mt-1"></i> My Bookings</a> -->
	                        <?php if(auth()->guard()->guest()): ?>
								<a class="btn btn-white text-cherry text-size-11 text-bold-600 mt-5 mb-5 mt-10--md mb-10--md mt-10--sm mb-10--sm mt-10--xs mb-10--xs text-uppercase" href="<?php echo e(url('/register')); ?>"><!--<i class="zmdi zmdi-power text-size-15 mr-6 float-left mt-1"></i> --> Register</a>
								<a class="btn btn-white text-cherry text-size-11 text-bold-600 mt-5 mb-5 mt-10--md mb-10--md mt-10--sm mb-10--sm mt-10--xs mb-10--xs text-uppercase" href="<?php echo e(url('/login')); ?>"><!--<i class="zmdi zmdi-power text-size-15 mr-6 float-left mt-1"></i> --> Login</a>
							<?php else: ?>
							<a class="btn btn-white text-cherry text-size-11 text-bold-600 mt-5 mb-5 mt-10--md mb-10--md mt-10--sm mb-10--sm mt-10--xs mb-10--xs text-uppercase" href="<?php echo e(url('/register-vehicle')); ?>"><!--<i class="zmdi zmdi-power text-size-15 mr-6 float-left mt-1"></i> --> Register Your Vehicle</a>
							
							<a class="btn btn-white text-cherry text-size-11 text-bold-600 mt-5 mb-5 mt-10--md mb-10--md mt-10--sm mb-10--sm mt-10--xs mb-10--xs text-uppercase" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
							 document.getElementById('logout-form').submit();"><!--<i class="zmdi zmdi-power text-size-15 mr-6 float-left mt-1"></i> --> Logout</a>
							 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
								<?php echo csrf_field(); ?>
							 </form>
						<?php endif; ?>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
		<div class="container">

			<div class="main-header-container">

				<div class="logo" data-mobile-logo="assets/images/logo/logo-dark.png" data-sticky-logo="assets/images/logo/logo-dark.png">
					<a href="<?php echo e(url('/')); ?>"><img src="assets/images/logo/logo-dark.png" alt="Online Vehicle Parking Management System"/></a>
				</div> <!-- /LOGO -->

				<div class="burger-menu">
					<div class="line-menu line-half first-line"></div>
					<div class="line-menu"></div>
					<div class="line-menu line-half last-line"></div>
				</div> <!-- /BURGER MENU -->

				<?php echo $__env->make('_partials.front-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div> <!-- /HEADER CONTAINER -->

		</div> <!-- /CONTAINER -->
	</div> <!-- /HEADER -->

	<?php echo $__env->yieldContent('content'); ?>
	
	<!--
    #################################
        - Begin: FOOTER -
    #################################
    -->
    <footer class="footer">
        <div class="bg-dark pt-60 pb-30">
            <div class="container">
                
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="bs-solid bc-v2-light bw-s1 bt-0 bl-0 br-0 pb-40 mb-50">
                            
                            <div class="row">
                                
                                <div class="col-md-6">
                                    <!-- Begin: LOGO -->
                                    <a class="navbar-brand logo text-cherry" href="index.html">
                                        <img class="full-width max-width-140 m-right-10" alt="Vehicle Parking System" src="">
                                    </a>
                                    <span class="text-white">/ Reserve parking slot</span>
                                    <!-- End: LOGO -->
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Begin: SOCIAL -->
                                    
                                    <!-- End: SOCIAL -->
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
                
                <div class="row">
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="mb-30">
                            <h5 class="text-bold-700 mb-30 text-white text-uppercase">Contact Us</h5>
                            <div class="row">
                                <div class="col-lg-12 col-md-6">
                                    <div class="row mb-20 map-bg">
                                        <div class="col-md-12 text-white">
				                            <address> <abbr title="Address"><strong>Address:</strong></abbr><br> Demo Address, Multan<br> Multan </address>
				                            <address> <abbr title="Phone"><strong>Phone:</strong></abbr><br> (123) 456-7890 </address>
				                            <address> <abbr title="Email"><strong>Email:</strong></abbr><br> <a class="text-cherry" href="mailto:#">info@ovpms.com</a> </address>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="mb-30">
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-12">
                        <div class="mb-30">
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </footer>

	<footer class="bg-dark pt-s1 pb-s1">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<div class="mt-s2 mb-s2 text-white">
						<p class="m-0 text-white">&copy; Copyright <?php echo e(date('Y')); ?> by <abbr title="Parking"><a href="#" class="text-white">Online Vehicle Parking Management System</a></abbr>. </p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12">
					<div class="mt-s2 mb-s2 text-white text-right">
						<a class="text-white" href="#">All Rights Reserved.</a>
					</div>
				</div>
			</div> <!-- /ROW -->
		</div> <!-- /CONTAINER -->
	</footer>
    <!-- End: FOOTER -
    ################################################################## -->

	<script src="<?php echo e(asset('public/assets/front/js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/vendors/appear/jquery.appear.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/vendors/jquery.easing/jquery.easing.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/vendors/common/common.min.js')); ?>"></script>

	<!-- FANCY-BOX -->
	<script src="<?php echo e(asset('public/assets/front/vendors/fancybox/jquery.fancybox.min.js')); ?>"></script>

	<!-- MENU -->
	<script src="<?php echo e(asset('public/assets/front/vendors/menu/src/main.menu.js')); ?>"></script>

	<!-- CAROUSEL -->
	<script src="<?php echo e(asset('public/assets/front/vendors/owl.carousel/owl.carousel.min.js')); ?>"></script>

	<!-- ANIMATED-HEADLINES -->
	<script src="<?php echo e(asset('public/assets/front/vendors/animated-headline/js/animated-headline.js')); ?>"></script>

	<!-- THEME-CUSTOM -->
	<script src="<?php echo e(asset('public/assets/front/js/main.js')); ?>"></script>

	<!-- THEME-INITIALIZATION-FILES -->
	<script src="<?php echo e(asset('public/assets/front/js/theme.init.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/front/js/custom.js')); ?>"></script>

</body>
</html><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/layouts/front.blade.php ENDPATH**/ ?>