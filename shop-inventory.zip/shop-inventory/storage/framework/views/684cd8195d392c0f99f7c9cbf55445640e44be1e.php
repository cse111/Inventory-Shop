
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Parking Area</h1>
	<nav>
		<ol class="breadcrumb">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Home</a></li>
		  <li class="breadcrumb-item">Parking Area Slot</li>
		  <li class="breadcrumb-item active">List</li>
		</ol>
	</nav>
</div>
<section class="section">
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<h5 class="card-title">Parking Area Slot List</h5>
					<?php if(session()->has('message')): ?>
						<div class="col-lg-12 col-md-12 alert alert-info">
							<?php echo session('message'); ?>

						</div>
					<?php endif; ?>
					<!-- Primary Color Bordered Table -->
					<table class="table table-bordered border-primary">
						<thead>
							<tr>
								<th scope="col">Sr #</th>
								<th scope="col">Parking Area Name</th>
								<th scope="col">Slot #</th>
								<th scope="col">Status</th>
								<th scope="col">Requested By Vehicle</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $parking_area_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$parking_area_slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th scope="row"><?php echo e($key+1); ?></th>
									<td><?php echo e($parking_area_slot->getParkingAreaDetail->name); ?></td>
									<td><?php echo e($parking_area_slot->slot_no); ?></td>
									<td>
										<?php if($parking_area_slot->status==0): ?>
											Available
										<?php endif; ?>
									</td>
									<td><?php echo e($parking_area_slot->vehicle_id); ?></td>
									<td>
										<a href="<?php echo e(url('admin/parking-area-slot/edit/'.$parking_area_slot->id)); ?>"><i class="ri-file-edit-fill"></i></a>
										<a href="<?php echo e(url('admin/parking-area-slot/delete/'.$parking_area_slot->id)); ?>" onclick="return confirm('Are you sure you want to delete this parking area slot?');"><i class="ri-delete-bin-2-fill"></i></a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<!-- End Primary Color Bordered Table -->
				</div>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\ovpms\resources\views/admin/parking-area-slot/index.blade.php ENDPATH**/ ?>