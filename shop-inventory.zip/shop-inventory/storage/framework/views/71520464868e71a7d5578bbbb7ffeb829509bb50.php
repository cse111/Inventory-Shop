<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>

<h3>Online Vehicle Parking Management System</h3>
Dear <?php echo e($name); ?>,<br>

As you have requested the reservation of following parking area slot:<br><br>

Parking Area: <?php echo e($parking_area); ?><br>
Parking Area Slot: <?php echo e($parking_area_slot); ?><br>

<p>It is <?php echo e($status); ?> by parking area admin.</p>

Thanks for your reservation.<br><br>

br,<br>
Parking Area Admin
</body>
</html><?php /**PATH D:\xampp\htdocs\ovpms\resources\views/admin/email/parking-area-slot-email.blade.php ENDPATH**/ ?>