<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth,App\Models\UserVehicle;

class RegisterVehicleController extends Controller
{
    public function getCreate() {
		return view('front.vehicle.create');
	}
	
	public function postCreate(Request $request) {
		UserVehicle::updateOrCreate(['user_id' => Auth::user()->id],$request->all());
		return redirect('register-vehicle')->with('message', 'Vehicle Has Been Registered Successfully.');
	}
	
	
}
