<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ParkingArea,App\Models\ParkingAreaSlot,Auth;

class HomeController extends Controller
{
    public function getIndex() {
		return view('front.index');
	}
	
	public function parkingArea(Request $request) {
		$parking_areas = ParkingArea::select('*');
		if($request->parking_area) {
			$parking_areas = $parking_areas->where('name','like','%'.$request->parking_area.'%');
		}
		$parking_areas = $parking_areas->get();
		return view('front.parking-area',compact(['parking_areas']));
	}
	
	public function getParkingAreaSlot($id) {
		$parking_area_slots = ParkingAreaSlot::where('parking_area_id',$id)->where('status',0)->get();
		return view('front.parking-area-slot',compact(['parking_area_slots']));
	}
	
	public function getReserveParkingAreaSlot($id) {
		ParkingAreaSlot::find($id)->update(['status' => 1, 'vehicle_id' => Auth::user()->getVehicleDetail->id]);
		return redirect('parking-area-slot-reserved/'.$id);
	}
	
	public function getParkingAreaSlotReserved($id) {
		$parking_area_slot = ParkingAreaSlot::find($id);
		return view('front.parking-area-slot-reserved',compact(['parking_area_slot']));
	}
}
