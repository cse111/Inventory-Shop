<?php

namespace App\Http\Controllers\Api;

use App\Enums\ResponseType;
use App\Helpers\StorageManager;
use App\Http\Controllers\Controller;
use App\Http\Requests\MemberCreateRequest;
use App\Http\Requests\MemberUpdateRequest;
use App\Http\Resources\Collections\UserCollection;
use App\Models\EmploymentHistory;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::members();
        $query = $this->membersRequestFilter($request, $query);
        return parent::paginatedIndex($request, $query);
    }

    /**
     * @param Request $request
     * @param $query
     * @return mixed
     */
    public function membersRequestFilter(Request $request, $query)
    {
        if ($request->has('age_group') && $request->age_group != 'all') {
            $age_group = $request->age_group;
            $date = Carbon::now()->subYears(35);
            if ($age_group == 'youth') {
                $query = $query->where('dob', '>=', $date);
            } else if ($age_group == 'adults') {
                $query = $query->where('dob', '<', $date);
            }
        }
        if ($request->has('company') && $request->company != 'all') {
            $query->whereHas('employment_histories', function ($q) use ($request) {
                $q->where('id', $request->company);
            });
        }
        return $query;
    }

    protected function toPaginatedResponse($records)
    {
        return new UserCollection($records, ResponseType::PAGINATED);
    }

    protected function applySearchFilters(&$query, $terms)
    {
        $query->where('name', 'LIKE', "%$terms%")
            ->orWhere('membership_number', 'LIKE', "%$terms%")
            ->orWhere('email', 'LIKE', "%$terms%")
            ->orWhere('mobile_number', 'LIKE', "%$terms%");
    }

    public function destroy(Request $request, User $member)
    {
        $member->delete();
        return response()->json(['message' => 'Member deleted successfully.']);
    }

    public function store(MemberCreateRequest $request)
    {
        $path = null;
        if ($request->hasFile('image')) {
            $path = StorageManager::uploadFile($request->image);
        } elseif ($request->has('encoded_image')) {
            $file_path_name = time() . '' . rand(10, 100) . '-' . str_replace(' ', '', 'member-image.png');
            $path = $this->base64_to_jpeg($request->encoded_image, '/images/' . $file_path_name);
            //$file = (public_path($image));
            //$path = StorageManager::uploadFile($file);
        }
        
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'gender' => $request->gender,
            'mobile_number' => $request->mobile_number,
            'father_name' => $request->father_name,
            'address' => $request->address,
            'dob' => $request->dob,
            'age' => Carbon::parse($request->dob)->age,
            'image' => $path,
            'membership_number' => '1'
        ]);
        if ($request->has('employment_history') && $request->employment_history != null && $request->employment_history != 'null' && $request->employment_history != '') {
            $histories = json_decode($request->employment_history);
            if (count($histories) > 0) {
                foreach ($histories as $history) {
                    EmploymentHistory::create([
                        'company_name' => $history->company_name,
                        'designation' => $history->designation,
                        'membership_date_to_union' => $history->membership_date_to_union != '' ? $history->membership_date_to_union : null,
                        'wef' => $history->wef != '' ? $history->wef : null,
                        'present_grade' => $history->present_grade,
                        'first_appointment' => $history->first_appointment,
                        'phone_number' => $history->phone_number,
                        'description' => $history->description,
                        'is_working' => true,
                        'user_id' => $user->id,
                    ]);
                }
            }
        }
        $this->setPassword($request, $user);
        $user->update(['membership_number' => 1000 + ($user->id * 3)]);
        return response()->json(['member' => $user]);
    }

    public function update(MemberUpdateRequest $request, User $member)
    {
        $path = $member->getRawOriginal('image');
        if ($request->hasFile('image')) {
            $path = StorageManager::uploadFile($request->image);
        }
        $member->update([
            'name' => $request->name,
            'gender' => $request->gender,
            'email' => $request->email,
            'mobile_number' => $request->mobile_number,
            'father_name' => $request->father_name,
            'address' => $request->address,
            'image' => $path,
            'dob' => $request->dob,
        ]);
        $this->setPassword($request, $member);
        if ($request->has('employment_history')) {
            $histories = json_decode($request->employment_history);
            if (count($histories) > 0) {
                foreach ($histories as $history) {
                    $id = property_exists($history, 'id') ? $history->id : 0;
                    EmploymentHistory::updateOrCreate(
                        [
                            'id' => $id
                        ],
                        [
                            'company_name' => $history->company_name,
                            'designation' => $history->designation,
                            'membership_date_to_union' => $history->membership_date_to_union,
                            'wef' => $history->wef,
                            'present_grade' => $history->present_grade,
                            'first_appointment' => $history->first_appointment,
                            'phone_number' => $history->phone_number,
                            'description' => $history->description,
                            'is_working' => true,
                            'user_id' => $member->id,
                        ]);
                }
            }
        }
        return response()->json(['member' => $member]);
    }

    private function setPassword($request, $user)
    {
        if ($request->has('password') && $request->password != null) {
            $user->update(['password' => Hash::make($request->password)]);
        }
    }

    public function updatePhoto(Request $request)
    {
        $user = Auth::user();
        $path = $user->getRawOriginal('image');
        if ($request->hasFile('image')) {
            $path = StorageManager::uploadFile($request->image);
        } else if ($request->has('encoded_image')) {
            $file_path_name = time() . '' . rand(10, 100) . '-' . str_replace(' ', '', 'member-image.png');
            $path = $this->base64_to_jpeg($request->encoded_image, '/images/' . $file_path_name);
        }
        $user->update(['image' => $path]);
        return response()->json(['message' => 'Photo updated successfully']);
    }

    public function login(Request $request)
    {
        $email = $request->email;
        $response = null;
        if (!Auth::attempt($request->only('email', 'password'))) {
            $response = response()->json(['message' => 'Invalid email or password'], 403);
        } else {
            $user = User::where('email', $email)->first();
            $token = $user->createToken('API Token')->plainTextToken;
            $response = response()->json(['token' => $token, 'user' => $user]);
        }
        return $response;
    }

    public function info(Request $request)
    {
        $user = $request->user();
        return response()->json(['user' => $user, 'employment_histories' => $user->employment_histories]);
    }

    public function members(Request $request)
    {
        $query = User::members();
        $query = $this->membersRequestFilter($request, $query);
        if ($request->search != null && $request->search != "") {
            $this->applySearchFilters($query, $request->search);
        }
        return response()->json(['members' => $query->get()]);
    }

    public function member(Request $request, User $member)
    {
        return response()->json(['member' => $member, 'employment_histories' => $member->employment_histories]);
    }

    function base64_to_jpeg($base64_string, $output_file)
    {
        // open the output file for writing
        $path = "storage/images";
        if (!file_exists($path)) {
            mkdir($path, 0755, true);
        }
        $ifp = fopen('storage/' . $output_file, 'wb');

        // split the string on commas
        // $data[ 0 ] == "data:image/png;base64"
        // $data[ 1 ] == <actual base64 string>
        $data = explode(',', $base64_string);
        // we could add validation here with ensuring count( $data ) > 1
        if (isset($data[1])) {
            fwrite($ifp, base64_decode($data[1]));
        } else {
            fwrite($ifp, base64_decode($base64_string));
        }

        // clean up the file resource
        fclose($ifp);

        return $output_file;
    }
}
