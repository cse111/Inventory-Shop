<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        return Product::all();
    }
	
	public function store(Request $request)
    {
        $input = $request->all();
		$product = Product::create($input);
        
        return response()->json(['product' => $product]);
    }
	
	public function update(Request $request,$id)
    {
        $product = Product::find($id);
		$product->update($request->all());
        
        return response()->json(['product' => $product]);
    }
	
	public function destroy($id)
    {
        $product = Product::find($id);
		$product->delete();
        
        return response()->json(['message' => 'Product Has Been Removed Successfully']);
    }
}
