<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth,App\Models\Product;

class DashboardController extends Controller
{
    public function index() {
		return view('admin.index');
	}
}
