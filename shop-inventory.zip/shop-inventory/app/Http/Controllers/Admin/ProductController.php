<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth,App\Models\Product;

class ProductController extends Controller
{
    public function getIndex() {
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
			CURLOPT_URL => url('api/products'),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_TIMEOUT => 30000,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				// Set Here Your Requesred Headers
				'Content-Type: application/json',
			),
		));
	
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if($err) {
			echo "cURL Error #:" . $err;
		} else {
			$products = json_decode($response);
		}
		
		return view('admin.product.index',compact(['products']));
	}
	
	public function getCreate() {
		return view('admin.product.create');
	}
	
	public function getEdit(Request $request,$id) {
		$product = Product::find($id);
		return view('admin.product.update',compact(['product']));
	}
	
}
