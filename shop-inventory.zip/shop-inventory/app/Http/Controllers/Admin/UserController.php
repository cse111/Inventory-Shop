<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth,App\Models\User;

class UserController extends Controller
{
    public function getUsers() {
		$users = User::all();
		return view('admin.user.index',compact(['users']));
	}
	
	public function profile(Request $request) {
		if($request->isMethod('post')) {
			$input = $request->all();
			$input['password'] = ($request->password)?bcrypt($request->password):Auth::user()->password;
			User::updateOrCreate(['id' => Auth::user()->id],$input);
			return redirect('admin/profile')->with('message', 'Profile Has Been Updated Successfully');
		}
		return view('admin.user.profile');
	}
	
}
